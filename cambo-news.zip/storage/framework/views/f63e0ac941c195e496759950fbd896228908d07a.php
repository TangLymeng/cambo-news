<?php $__env->startSection('heading', 'All Pending Comment'); ?>

<?php $__env->startSection('main_content'); ?>
    <div class="section-body">
        <div class="row">
            <div class="col-12">
                <div class="card">
                    <div class="card-body">
                        <div class="table-responsive">
                            <table class="table table-bordered" id="example1">
                                <thead>
                                <tr>
                                    <th>SL</th>
                                    <th>Image</th>
                                    <th>News</th>
                                    <th>UserName</th>
                                    <th>Comment</th>
                                    <th>Status</th>
                                    <th>Action</th>
                                </tr>
                                </thead>
                                <tbody>
                                <?php $__currentLoopData = $review; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td><?php echo e($loop->iteration); ?></td>
                                        <td><img src="<?php echo e(asset('uploads/'.$row['rnews']['post_photo'])); ?> "
                                                 style="width:200px"></td>
                                        <td><?php echo e($row['rnews']['post_title']); ?></td>
                                        <td><?php echo e($row['ruser']['name']); ?></td>
                                        <td><?php echo e(Str::limit($row->comment, 25)); ?></td>
                                        <td>
                                            <?php if($row->status == 0): ?>
                                                <span class="badge badge-pill bg-danger">Pending</span>

                                            <?php else: ?>
                                                <span class="badge badge-pill bg-success">Publish</span>
                                            <?php endif; ?>
                                        </td>
                                        <td>
                                            <a href="<?php echo e(route('admin_comment_approve',$row->id)); ?>"
                                               class="btn btn-primary rounded-pill waves-effect waves-light">Approve</a>
                                            <a href="<?php echo e(route('admin_comment_reject',$row->id)); ?> "
                                               class="btn btn-danger rounded-pill waves-effect waves-light">Reject</a>

                                        </td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layout.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/thunder-news/resources/views/admin/pending_review.blade.php ENDPATH**/ ?>