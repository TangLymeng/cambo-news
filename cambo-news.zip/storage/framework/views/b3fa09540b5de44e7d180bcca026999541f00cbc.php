<div class="main-sidebar">
    <aside id="sidebar-wrapper">
        <div class="sidebar-brand">
            <a href="<?php echo e(route('admin_home')); ?>">Admin Panel</a>
        </div>
        <div class="sidebar-brand sidebar-brand-sm">
            <a href="<?php echo e(route('admin_home')); ?>"></a>
        </div>

        <ul class="sidebar-menu">

            <li class="<?php echo e(Request::is('admin/home') ? 'active' : ''); ?>"><a class="nav-link"
                                                                           href="<?php echo e(route('admin_home')); ?>"><i
                        class="fas fa-home fa-spin"></i> <span>Dashboard</span></a></li>

            <li class="<?php echo e(Request::is('admin/setting') ? 'active' : ''); ?>"><a class="nav-link"
                                                                           href="<?php echo e(route('admin_setting')); ?>"><i
                        class="fas fa-fire"></i> <span>Breaking News/News Ticker</span></a></li>

            <li class="nav-item dropdown <?php echo e(Request::is('admin/top-advertisement')||Request::is('admin/home-advertisement')||Request::is('admin/sidebar-advertisement') ? 'active' : ''); ?>">
                <a href="#" class="nav-link has-dropdown"><i
                        class="fas fa-ad fa-pulse"></i><span>Advertisements</span></a>
                <ul class="dropdown-menu">
                    <li class="<?php echo e(Request::is('admin/top-advertisement') ? 'active' : ''); ?>"><a class="nav-link"
                                                                                                href="<?php echo e(route('admin_top_ad_show')); ?>"><i
                                class="fas fa-ad"></i> Top Advertisement</a></li>
                    <li class="<?php echo e(Request::is('admin/home-advertisement') ? 'active' : ''); ?>"><a class="nav-link"
                                                                                                 href="<?php echo e(route('admin_home_ad_show')); ?>"><i
                                class="fas fa-ad"></i> Home Advertisement</a></li>
                    <li class="<?php echo e(Request::is('admin/sidebar-advertisement') ? 'active' : ''); ?>"><a class="nav-link"
                                                                                                    href="<?php echo e(route('admin_sidebar_ad_show')); ?>"><i
                                class="fas fa-ad"></i> Sidebar Advertisement</a></li>
                </ul>
            </li>

            <li class="nav-item dropdown <?php echo e(Request::is('admin/category/show')||Request::is('admin/sub-category/show')||Request::is('admin/post/show') ? 'active' : ''); ?>">
                <a href="#" class="nav-link has-dropdown"><i class="far fa-newspaper"></i><span>News</span></a>
                <ul class="dropdown-menu">
                    <li class="<?php echo e(Request::is('admin/category/show') ? 'active' : ''); ?>"><a class="nav-link"
                                                                                            href="<?php echo e(route('admin_category_show')); ?>"><i
                                class="fas fa-angle-right"></i> Categories</a></li>
                    <li class="<?php echo e(Request::is('admin/sub-category/show') ? 'active' : ''); ?>"><a class="nav-link"
                                                                                                href="<?php echo e(route('admin_sub_category_show')); ?>"><i
                                class="fas fa-angle-right"></i> SubCategories</a></li>
                    <li class="<?php echo e(Request::is('admin/post/show') ? 'active' : ''); ?>"><a class="nav-link"
                                                                                         href="<?php echo e(route('admin_post_show')); ?>"><i class="fas fa-angle-right"></i> Posts</a></li>
                </ul>
            </li>

            <li class="<?php echo e(Request::is('admin/pending/comment') ? 'active' : ''); ?>"><a class="nav-link"
                                                                              href="<?php echo e(route('admin_pending_comment')); ?>"><i
                        class="fas fa-comment fa-spin"></i> <span>Pending Comment</span></a></li>
            <li class="<?php echo e(Request::is('admin/approved/comment') ? 'active' : ''); ?>"><a class="nav-link"
                                                                                      href="<?php echo e(route('admin_comment_approved')); ?>"><i
                        class="fas fa-comment"></i> <span>Approved Comment</span></a></li>

















        </ul>
    </aside>
</div>
<?php /**PATH /var/www/html/thunder-news/resources/views/admin/layout/sidebar.blade.php ENDPATH**/ ?>