<script src="{{ asset('dist-front/js/custom.js') }}"></script>
